import pytest

from datadog_checks.pihole import PiholeCheck
from datadog_checks.base import ConfigurationError


@pytest.mark.unit
def test_config():
    instance = {}
    c = PiholeCheck('pihole', {}, [instance])

    #empty should fail
    with pytest.raises(ConfigurationError):
        c.check(instance)


@pytest.mark.integrations
@pytest.mark.usefixtures('dd_environment')
def test_service_check(aggregator, instance):
    c = PiholeCheck('pihole', {'host': 'localhost'})

    c.check(instance)
    aggregator.assert_service_check('pihole.running', PiholeCheck.OK)
