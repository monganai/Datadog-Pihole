from .__about__ import __version__
from .pihole import PiholeCheck

__all__ = ['__version__', 'PiholeCheck']
